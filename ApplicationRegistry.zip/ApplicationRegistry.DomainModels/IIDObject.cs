﻿namespace ApplicationRegistry.DomainModels
{
    public interface IIDObject
    {
        int ID { get; set; }
    }
}
