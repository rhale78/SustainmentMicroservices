﻿namespace ApplicationRegistry.Model
{
    public class ApplicationActiveRequest
    {
        public string FriendlyName { get; set; }
        public int ApplicationInstanceID { get; set; }
    }
}
