﻿namespace ApplicationRegistry.Model
{
    public class ApplicationActiveResult
    {
        public bool IsActive { get; set; }
        public bool IsAvailable { get; set; }
    }
}
