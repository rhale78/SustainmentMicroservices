﻿namespace ApplicationRegistry.Model
{
    public class ApplicationDiscoveryMethod
    {
        public string HttpMethod { get; set; }
        public string MethodName { get; set; }
        public string Template { get; set; }
    }
}
