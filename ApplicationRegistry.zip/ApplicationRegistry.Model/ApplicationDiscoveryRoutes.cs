﻿namespace ApplicationRegistry.Model
{
    public class ApplicationDiscoveryRoutes
    {
        public List<ApplicationDiscoveryRouteItem> Routes { get; set; } = new List<ApplicationDiscoveryRouteItem>();
    }
}
