﻿namespace ApplicationRegistry.Model
{
    public class ApplicationDiscoveryURL
    {
        public string URL { get; set; }
        public int? Port { get; set; }
    }
}
