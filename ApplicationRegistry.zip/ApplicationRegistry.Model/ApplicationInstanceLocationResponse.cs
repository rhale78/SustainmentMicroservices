﻿namespace ApplicationRegistry.Model
{
    public class ApplicationInstanceLocationResponse
    {
        public string ServerName { get; set; }
        public string Path { get; set; }
    }
}
