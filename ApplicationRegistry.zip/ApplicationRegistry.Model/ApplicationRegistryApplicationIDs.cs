﻿namespace ApplicationRegistry.Model
{
    public class ApplicationRegistryApplicationIDs
    {
        public int ApplicationRegistryItemID { get; set; }
        public int ApplicationRegistryVersionID { get; set; }
        public int ApplicationRegistryInstanceID { get; set; }
    }
}
