﻿namespace ApplicationRegistry.Model
{
    public class InstanceHeartbeat
    {
        public int ApplicationInstanceID { get; set; }
    }
}
