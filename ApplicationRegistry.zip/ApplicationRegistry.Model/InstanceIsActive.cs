﻿namespace ApplicationRegistry.Model
{
    public class InstanceIsActive
    {
        public int ApplicationInstanceID { get; set; }
        public bool Starting { get; set; }
    }
}
