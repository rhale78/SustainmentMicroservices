﻿namespace ApplicationRegistry.Model
{
    public class WhoIsRequest
    {
        public int ApplicationInstanceID { get; set; }
    }
}
