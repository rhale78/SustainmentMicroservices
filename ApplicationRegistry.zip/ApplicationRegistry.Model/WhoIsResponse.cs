﻿namespace ApplicationRegistry.Model
{
    public class WhoIsResponse
    {
        public string ApplicationName { get; set; }
    }
}
