﻿namespace Common.Dependencies
{
    public class Dependencies
    {
        public static string Hash { get; set; }
        public static string Path { get; set; }
        public static string? ApplicationName { get; set; }
        public static int ApplicationInstanceID { get; set; }
    }
}
