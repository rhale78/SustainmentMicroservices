﻿using Microsoft.AspNetCore.Mvc;

namespace RegistryTest
{
    [ApiController]
    [Route("[controller]/")]
    public class TestController : ControllerBase
    {
        [HttpGet("Test")]
        public string Test()
        {
            return "Test";
        }
    }
    [ApiController]
    [Route("[controller]/")]
    public class Test1Controller : ControllerBase
    {
        [HttpPost("Test1")]
        public string Test1()
        {
            return "Test1";
        }
    }
}
